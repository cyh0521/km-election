#!/usr/bin/env node
// ================================================================
// build-summaries.js
// 掃描所有 availableElections 的 CSV，產生前端首頁所需的摘要 JSON。
//
// 使用：
//   cd km-election/
//   node build-summaries.js
//
// 產出：
//   elections-summaries.json
//
// 說明：
//   前端首頁原本會並發 fetch 所有 316 個 CSV，只為了拿「有效票/無效票/
//   選舉人數」等摘要資料。本腳本改為離線預處理：把所有摘要集中到一個
//   JSON 檔，前端首頁只要 fetch 這一個檔即可瞬間取得全部資料。
// ================================================================

'use strict';
const fs = require('fs');
const path = require('path');

// --- 載入 elections-data.js ---
const electionsDataSrc = fs.readFileSync(
  path.join(__dirname, 'elections-data.js'),
  'utf8'
);
// 用 sandbox 的方式執行，取得 availableElections
const sandbox = { window: {} };
const fn = new Function('window', electionsDataSrc);
fn(sandbox.window);
const availableElections = sandbox.window.availableElections;

if (!Array.isArray(availableElections)) {
  console.error('讀取 elections-data.js 失敗，找不到 availableElections');
  process.exit(1);
}

console.log(`載入選舉清單完成：${availableElections.length} 筆`);

// --- extractCountySummary: 完整複製自 script.js 的邏輯 ---
// 為了讓摘要與前端實際解析結果完全一致，這裡不走捷徑。
function extractCountySummary(text, partyColorsTracker) {
  const rows = text.split('\n').map(r => r.trim()).filter(r => r).map(r => r.split(','));
  if (rows.length < 4) return null;

  // 去除 BOM
  if (rows[0][0] && rows[0][0].charCodeAt(0) === 0xFEFF) {
    rows[0][0] = rows[0][0].slice(1);
  }

  const electionNameFromCSV = rows[0] && rows[0][0] ? rows[0][0].trim() : '';
  const electionDateFromCSV = rows[0] && rows[0][1] ? rows[0][1].trim() : '';

  const headerRowIndices = [];
  let currentIdx = 2;
  while (rows[0][currentIdx] && rows[1][currentIdx]) {
    headerRowIndices.push(currentIdx);
    currentIdx++;
  }

  const seatsCount = rows[1] && rows[1][0] ? rows[1][0].trim() : '';
  const VOTES_COL = currentIdx;
  const INVALID_COL = currentIdx + 1;
  const ELIGIBLE_COL = currentIdx + 2;

  const candInfo = [];
  let independentCounter = 1;

  headerRowIndices.forEach(colIndex => {
    const number = rows[0][colIndex] ? rows[0][colIndex].trim() : '';
    let name = rows[1][colIndex] ? rows[1][colIndex].trim() : '';
    let party = rows[2][colIndex] ? rows[2][colIndex].trim() : '';

    const bracketMatch = name.match(/\[(.*?)\]/);
    const bracketText = bracketMatch ? bracketMatch[1] : null;

    const isWomenQuota = name.includes('*!');
    const isIncumbent = name.includes('#');
    const isWinner = name.includes('*') || isWomenQuota;

    name = name.replace(/\[.*?\]/g, '').replace('*!', '').replace('*', '').replace('#', '').trim();
    party = party === '無' ? '無黨籍' : party;

    if (name && number) {
      if (party === '無黨籍') {
        party = `無黨籍-${independentCounter}`;
        independentCounter++;
      }
      candInfo.push({ number: String(number), name, party, colIndex, isWinner, isWomenQuota, isIncumbent, bracketText });
    }
  });

  const candidates = {};
  let globalValidVotes = 0;
  let globalInvalidVotes = 0;
  let globalEligibleVoters = 0;

  const parseNum = (val) => parseInt(String(val).replace(/[^0-9]/g, '')) || 0;

  for (let i = 3; i < rows.length; i++) {
    const row = rows[i];
    if (row.length < (ELIGIBLE_COL + 1) || !row[0] || row[0].includes('鄉鎮')) continue;

    const validVotes = parseNum(row[VOTES_COL]);
    const invalidVotes = parseNum(row[INVALID_COL]);
    const eligibleVoters = parseNum(row[ELIGIBLE_COL]);

    globalValidVotes += validVotes;
    globalInvalidVotes += invalidVotes;
    globalEligibleVoters += eligibleVoters;

    candInfo.forEach(c => {
      const votes = parseNum(row[c.colIndex]);
      if (!candidates[c.name]) {
        candidates[c.name] = {
          number: c.number,
          party: c.party,
          votes: 0,
          isWinner: c.isWinner,
          isWomenQuota: c.isWomenQuota,
          isIncumbent: c.isIncumbent,
          bracketText: c.bracketText
        };
      }
      candidates[c.name].votes += votes;
    });
  }

  const allCandidates = Object.keys(candidates).map(k => ({ name: k, ...candidates[k] }));

  return {
    allCandidates,
    metadata: {
      validVotes: globalValidVotes,
      invalidVotes: globalInvalidVotes,
      eligibleVoters: globalEligibleVoters,
      seatsCount,
      electionNameFromCSV,
      electionDateFromCSV
    }
  };
}

// --- 主流程 ---
const summaries = {};
let ok = 0, fail = 0;

for (const e of availableElections) {
  const full = path.join(__dirname, e.file);
  try {
    const text = fs.readFileSync(full, 'utf8');
    const summary = extractCountySummary(text);
    if (summary) {
      summaries[e.uniqueId] = summary;
      ok++;
    } else {
      summaries[e.uniqueId] = null;
      fail++;
      console.warn(`  [警告] ${e.file} 資料格式異常`);
    }
  } catch (err) {
    summaries[e.uniqueId] = null;
    fail++;
    console.warn(`  [錯誤] ${e.file}: ${err.message}`);
  }
}

const outPath = path.join(__dirname, 'elections-summaries.json');
const json = JSON.stringify(summaries);
fs.writeFileSync(outPath, json, 'utf8');

const size = fs.statSync(outPath).size;
const sizeKB = (size / 1024).toFixed(1);

console.log('');
console.log(`完成：${ok} 成功, ${fail} 失敗`);
console.log(`輸出：${outPath}`);
console.log(`大小：${sizeKB} KB（${availableElections.length} 筆選舉摘要）`);
console.log('');
console.log('提示：部署時請將 elections-summaries.json 一併上傳');
